package com.repository.recomputer

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.text.InputType
import android.util.Base64
import android.view.Gravity
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import rikka.shizuku.Shizuku
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {
    private var svc: IUserService? = null
    @Volatile private var stop = false
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var logView: TextView
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun log(s: String) { ui.post { logView.append(s + "\n") } }

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName, b: IBinder) { svc = IUserService.Stub.asInterface(b); log("shizuku shell ready, hit run") }
        override fun onServiceDisconnected(n: ComponentName) { svc = null }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("p", MODE_PRIVATE)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(40), dp(16), dp(16)) }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(ImageView(this).apply { setImageResource(R.drawable.cursor) }, LinearLayout.LayoutParams(dp(40), dp(40)))
        head.addView(TextView(this).apply { text = "  REComputer"; textSize = 24f })
        root.addView(head)
        val key = EditText(this).apply { hint = "openrouter api key"; setText(p.getString("k", "")); inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        val model = EditText(this).apply { hint = "model"; setText(p.getString("m", "nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free")) }
        val task = EditText(this).apply { hint = "what should i do? e.g. open brawl stars" }
        val row = LinearLayout(this)
        val run = Button(this).apply { text = "run" }
        val st = Button(this).apply { text = "stop"; setOnClickListener { stop = true } }
        row.addView(run); row.addView(st)
        logView = TextView(this).apply { textSize = 12f }
        val sv = ScrollView(this).apply { addView(logView) }
        listOf(key, model, task, row).forEach { root.addView(it) }
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        run.setOnClickListener {
            p.edit().putString("k", key.text.toString()).putString("m", model.text.toString()).apply()
            if (!Shizuku.pingBinder()) { log("shizuku isnt running, start it first"); return@setOnClickListener }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) { Shizuku.requestPermission(1); log("allow it in the popup, then hit run"); return@setOnClickListener }
            if (svc == null) {
                Shizuku.bindUserService(Shizuku.UserServiceArgs(ComponentName(packageName, ShellService::class.java.name)).processNameSuffix("shell").version(1), conn)
                log("connecting to shizuku..."); return@setOnClickListener
            }
            stop = false
            val t = task.text.toString(); val k = key.text.toString(); val m = model.text.toString()
            Thread { try { agent(t, k, m) } catch (e: Exception) { log("crash: ${e.message}") } }.start()
        }
    }

    private fun sh(cmd: String): ByteArray = ParcelFileDescriptor.AutoCloseInputStream(svc!!.exec(cmd)).use { it.readBytes() }

    private fun shot(): Triple<String, Int, Int>? {
        val png = sh("screencap -p")
        val bmp = BitmapFactory.decodeByteArray(png, 0, png.size) ?: return null
        val w = 540; val h = bmp.height * w / bmp.width
        val o = ByteArrayOutputStream()
        Bitmap.createScaledBitmap(bmp, w, h, true).compress(Bitmap.CompressFormat.JPEG, 70, o)
        return Triple(Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP), bmp.width, bmp.height)
    }

    private val sys = """You operate an Android phone by looking at screenshots. Coordinates are x,y from 0 to 1000 across the screen width and height.
Reply with ONE json object only, one of:
{"action":"open_app","package":"com.example.app"}
{"action":"tap","x":500,"y":500}
{"action":"swipe","x1":500,"y1":800,"x2":500,"y2":200}
{"action":"text","text":"hello"}
{"action":"key","key":"BACK"}  (BACK, HOME, ENTER)
{"action":"wait"}
{"action":"done","reason":"..."}
Prefer open_app for launching apps, using the package list. Say done when the task is finished."""

    private fun ask(task: String, hist: List<String>, b64: String, apps: String, k: String, m: String): String {
        val text = "TASK: $task\nINSTALLED APPS (label=package):\n$apps\nACTIONS SO FAR:\n${hist.joinToString("\n")}\nReply with ONE json object only."
        val user = JSONObject().put("role", "user").put("content", JSONArray()
            .put(JSONObject().put("type", "text").put("text", text))
            .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$b64"))))
        val body = JSONObject().put("model", m).put("max_tokens", 1500)
            .put("messages", JSONArray().put(JSONObject().put("role", "system").put("content", sys)).put(user))
        val c = URL("https://openrouter.ai/api/v1/chat/completions").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 30000; c.readTimeout = 120000
        c.setRequestProperty("Authorization", "Bearer $k"); c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val s = (if (c.responseCode in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
        if (c.responseCode !in 200..299) throw Exception("http ${c.responseCode}: ${s.take(200)}")
        return JSONObject(s).getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content")
    }

    private fun perform(a: JSONObject, W: Int, H: Int) {
        fun px(n: String) = (a.optDouble(n, 500.0) * W / 1000).toInt()
        fun py(n: String) = (a.optDouble(n, 500.0) * H / 1000).toInt()
        when (a.optString("action")) {
            "open_app" -> { val pk = a.optString("package"); if (Regex("[A-Za-z0-9._]+").matches(pk)) sh("monkey -p $pk -c android.intent.category.LAUNCHER 1") }
            "tap" -> sh("input tap ${px("x")} ${py("y")}")
            "swipe" -> sh("input swipe ${px("x1")} ${py("y1")} ${px("x2")} ${py("y2")} 300")
            "text" -> sh("input text '" + a.optString("text").replace(Regex("[^A-Za-z0-9 .,@_-]"), "").replace(" ", "%s") + "'")
            "key" -> { val kk = a.optString("key").uppercase(); if (Regex("[A-Z_]+").matches(kk)) sh("input keyevent KEYCODE_$kk") }
        }
    }

    private fun agent(task: String, k: String, m: String) {
        val apps = packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .joinToString("\n") { "${it.loadLabel(packageManager)}=${it.activityInfo.packageName}" }.take(4000)
        val hist = ArrayList<String>()
        for (n in 1..15) {
            if (stop) { log("stopped"); return }
            val s = shot() ?: run { log("screenshot failed"); return }
            val reply = try { ask(task, hist, s.first, apps, k, m) } catch (e: Exception) { log("api error: ${e.message}"); return }
            val a = try { JSONObject(reply.substring(reply.indexOf('{'), reply.lastIndexOf('}') + 1)) } catch (e: Exception) { log("bad reply: ${reply.take(200)}"); return }
            log("$n: $a"); hist.add("$n: $a")
            if (a.optString("action") == "done") { log("done"); return }
            perform(a, s.second, s.third)
            Thread.sleep(if (a.optString("action") == "open_app") 3000 else 1500)
        }
        log("hit step limit")
    }
}
