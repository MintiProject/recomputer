package com.repository.recomputer

import android.os.ParcelFileDescriptor

// runs inside the shizuku process with shell privileges
class ShellService : IUserService.Stub() {
    override fun destroy() { System.exit(0) }
    override fun exec(cmd: String): ParcelFileDescriptor {
        val pipe = ParcelFileDescriptor.createPipe()
        val p = ProcessBuilder("sh", "-c", cmd).start()
        Thread { try { p.errorStream.readBytes() } catch (_: Exception) {} }.start()
        Thread {
            try { ParcelFileDescriptor.AutoCloseOutputStream(pipe[1]).use { p.inputStream.copyTo(it) } } catch (_: Exception) {}
            p.waitFor()
        }.start()
        return pipe[0]
    }
}
