package com.repository.recomputer;
import android.os.ParcelFileDescriptor;
interface IUserService {
    void destroy() = 16777114;
    ParcelFileDescriptor exec(String cmd) = 1;
}
